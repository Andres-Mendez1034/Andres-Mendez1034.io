import React, { useState } from "react";
import './Auth.css';

/**
 * Componente de Autenticación (Login/Register)
 * Usa las clases definidas en Login.css (Brand Connect Ultra Boosted).
 *
 * Props:
 * - type: "login" | "register" (default: "login")
 * - onSubmit: (payload) => void  // callback opcional
 */
export default function Auth({ type = "login", onSubmit }) {
  const isLogin = type === "login";

  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  // Validaciones simples
  const validate = () => {
    if (!email || !pwd) return "Completa todos los campos.";
    const okEmail = /^\S+@\S+\.\S+$/.test(email);
    if (!okEmail) return "Ingresa un correo válido.";
    if (pwd.length < 6) return "La contraseña debe tener al menos 6 caracteres.";
    return "";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const msg = validate();
    if (msg) {
      setErr(msg);
      return;
    }
    setErr("");
    setLoading(true);
    try {
      // Simula procesamiento. Aquí luego conectaremos backend.
      await new Promise((r) => setTimeout(r, 600));
      onSubmit?.({ email, password: pwd, type });
      // Redirección opcional aquí si lo deseas.
    } catch (error) {
      setErr("No pudimos procesar tu solicitud. Intenta de nuevo.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      className="auth"
      aria-label={isLogin ? "Iniciar sesión" : "Crear cuenta"}
    >
      <div className="auth-card">
        {/* Header */}
        <header className="auth-header">
          <span className="auth-badge">{isLogin ? "Acceso" : "Registro"}</span>
          <h1 className="auth-title">
            {isLogin ? "Bienvenido de vuelta" : "Crea tu cuenta"}
          </h1>
          <p className="auth-subtitle">
            {isLogin
              ? "Ingresa a tu panel de Brand Connect"
              : "Únete a Brand Connect en minutos"}
          </p>
        </header>

        {/* Error global */}
        {err && (
          <div className="form-error" role="alert">
            {err}
          </div>
        )}

        {/* Formulario */}
        <form className="auth-form" onSubmit={handleSubmit} noValidate>
          {/* Email */}
          <div className="form-field">
            <label htmlFor="email">Correo</label>
            <div className="input-wrapper">
              <input
                id="email"
                className="input"
                type="email"
                placeholder="tu@email.com"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                aria-invalid={!!err && !email ? "true" : "false"}
              />
            </div>
          </div>

          {/* Password */}
          <div className="form-field">
            <label htmlFor="password">Contraseña</label>
            <div className="input-wrapper">
              <input
                id="password"
                className={`input${err && !pwd ? " error" : ""}`}
                type={showPwd ? "text" : "password"}
                placeholder="••••••••"
                autoComplete={isLogin ? "current-password" : "new-password"}
                value={pwd}
                onChange={(e) => setPwd(e.target.value)}
                required
                aria-invalid={!!err && !pwd ? "true" : "false"}
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => setShowPwd((v) => !v)}
                aria-label={showPwd ? "Ocultar contraseña" : "Mostrar contraseña"}
              >
                {showPwd ? "Ocultar" : "Mostrar"}
              </button>
            </div>
          </div>

          {/* Helpers */}
          <div className="auth-helpers">
            {/* Puedes convertir esto a <Link> si usas react-router */}
            <a className="link" href="/forgot">
              ¿Olvidaste tu contraseña?
            </a>
          </div>

          {/* Acciones */}
          <div className="auth-actions">
            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
              aria-busy={loading ? "true" : "false"}
            >
              {loading
                ? isLogin
                  ? "Entrando..."
                  : "Creando..."
                : isLogin
                ? "Iniciar sesión"
                : "Crear cuenta"}
            </button>

            {/* Acción secundaria */}
            {isLogin ? (
              <a className="btn btn-ghost" href="/register">
                Crear una cuenta
              </a>
            ) : (
              <a className="btn btn-ghost" href="/login">
                Ya tengo cuenta
              </a>
            )}
          </div>

          {/* Social (opcional) */}
          <div className="divider">o continúa con</div>
          <div className="socials">
            <button type="button" className="social-btn" onClick={() => alert("Google (demo)")}>
              Google
            </button>
            <button type="button" className="social-btn" onClick={() => alert("GitHub (demo)")}>
              GitHub
            </button>
          </div>
        </form>

        {/* Footer del auth */}
        <div className="auth-footer">
          {isLogin ? (
            <span>
              ¿No tienes cuenta?{" "}
              <a href="/register">Regístrate</a>
            </span>
          ) : (
            <span>
              ¿Ya tienes cuenta?{" "}
              <a href="/login">Inicia sesión</a>
            </span>
          )}
        </div>
      </div>
    </section>
  );
}