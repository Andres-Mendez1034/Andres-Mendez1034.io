import React from "react";
import Auth from "../../components/auth/Auth.jsx";
import "./Register.css";

export default function Register() {
  return <Auth type="register" />;
}