import React from "react";
import Auth from "../../components/auth/Auth.jsx";
import "./Login.css";

export default function Login() {
  return (
    <main className="page login-page" aria-label="Página de inicio de sesión">
      <section className="login-layout">
        {/* Panel visual/branding (opcional) */}
        <aside className="login-aside" aria-hidden="true">
          <div className="login-aside-inner">
            <span className="brand-badge">Brand Connect</span>
            <h1 className="aside-title">Inicia sesión</h1>
            <p className="aside-text">
              Accede a tu panel para gestionar campañas, analizar métricas y
              potenciar tu presencia en el marketplace.
            </p>
            <div className="aside-glow" />
          </div>
        </aside>

        {/* Card de autenticación */}
        <div className="login-auth">
          <Auth type="login" />
        </div>
      </section>
    </main>
  );
}