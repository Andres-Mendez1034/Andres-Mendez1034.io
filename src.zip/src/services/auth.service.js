// Servicio de autenticación (simulado)
export async function loginService({ email, password }) {
  // TODO: Reemplazar con fetch/axios al backend
  await new Promise(r => setTimeout(r, 500));
  return { token: 'fake-token', user: { id: 1, name: 'Usuario', email } };
}

export async function registerService({ name, email, password }) {
  await new Promise(r => setTimeout(r, 500));
  return { token: 'fake-token', user: { id: 2, name, email } };
}
